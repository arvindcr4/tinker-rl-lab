# Corrected PES defense, 11 October 2026

Use `TinkerRL_PES_Defense_2026-10-11.pptx`. It retains the original twelve-slide layout with editable text and shapes.

The correction record is `EDIT_RECORD.json`. Changes fix the unsaturated study's GRPO 8-by-8 versus PPO 64-by-1 budget, limit the ZVF claim to group-relative learning signal, qualify the extraction-failure explanation, and update the review date. Measured findings are unchanged.

`DEFENSE_BRIEF.md` is the full speaking brief. The parent `DEFENSE_PREP.md` is the shorter rehearsal guide. The slides and notes were inspected through the artifact renderer; no native PowerPoint presentation session is claimed.
